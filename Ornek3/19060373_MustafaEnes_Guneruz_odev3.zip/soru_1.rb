=begin
    Programlamaya Giriş - 1 Dersi    Ödev 3    Soru 1    
    Mustafa Enes Güneruz    19060373
=end

# Kümelerin (dizilerin) tanımlanması 
A = [3, 8, 15, 10, 26]
B = [-4, 456, 78, 1, 5]
C = [6, 9, -17, 86, 24]

#Üç kümenin birleşim kümesi:
birlesim = A | B | C

#sort ve reverse metodlarını kullanarak kümenin elemanlarının büyükten küçüğe sıralanması:
sirali_birlesim = birlesim.sort.reverse


puts "A kümesi: #{A}"
puts "B kümesi: #{B}"
puts "C kümesi: #{C}"
puts "Birleşim kümesi: #{birlesim}"
puts "Birleşim kümesinin büyükten küçüğe sıralı hali: #{sirali_birlesim}"

